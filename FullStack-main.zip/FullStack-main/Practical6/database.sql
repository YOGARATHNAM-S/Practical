CREATE DATABASE DETAILS;
USE DETAILS;
CREATE TABLE customer (
    Roll int,
    UName varchar(255),
    Email varchar(255),
    Contact varchar(255)
);